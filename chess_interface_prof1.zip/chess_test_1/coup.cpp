#include "coup.h"

coup::coup()
{
    //ctor
}




#include"position.h"
position::~position()
{
    delete psoeur;
    delete pfille;
}

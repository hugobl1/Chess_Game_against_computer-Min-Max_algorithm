#include<QTextStream>
#include <QMouseEventTransition>
#include "mainwindow.h"
#include "ui_mainwindow.h"

#include<iostream>
#include <QDebug>
#include<stdlib.h>
#include <QGraphicsTextItem>
#include <QBrush>
#include <QPalette>
#include <QPushButton>
#include <QLabel>
#include "echiquier.h"
#include "position_echec.h"
#include "coup.h"


MainWindow::MainWindow(QWidget *parent)
  : QMainWindow(parent)
  , ui(new Ui::MainWindow)
{  ui->setupUi(this);}

MainWindow::~MainWindow()
{  delete ui;}



position_echec* choisircoup(Couleur couleur, position_echec* chessboard)
{   piece vide;
    echiquier board(chessboard->liste);
    string caseastr,casebstr;
    int numa=0,numb=0,casea,caseb;
    bool erreur=true;
    piece p;
    while(erreur)
    {   erreur=false;
        cout<<"Quelle est la case de départ de la pièce jouée (exemple: e 6)?"<<endl;
        cin>>caseastr>>numa;
        if(caseastr=="a")             {   casea=1;     }
        else if(caseastr=="b")        {   casea=2;        }
        else if(caseastr=="c")        {   casea=3;        }
        else if(caseastr=="d")        {   casea=4;        }
        else if(caseastr=="e")        {   casea=5;        }
        else if(caseastr=="f")        {   casea=6;        }
        else if(caseastr=="g")        {   casea=7;        }
        else if(caseastr=="h")        {   casea=8;        }
        else{cout<<"Veuillez choisir une case du plateau!";
            erreur=true;        }
        cout<<"Quelle est la case d'arrivée de la pièce jouée?"<<endl;
        cin>>casebstr>>numb;
        if(casebstr=="a")        {   caseb=1;        }
        else if(casebstr=="b")        {   caseb=2;        }
        else if(casebstr=="c")        {   caseb=3;        }
        else if(casebstr=="d")        {   caseb=4;        }
        else if(casebstr=="e")        {   caseb=5;        }
        else if(casebstr=="f")        {   caseb=6;        }
        else if(casebstr=="g")        {   caseb=7;        }
        else if(casebstr=="h")        {   caseb=8;        }
        else{cout<<"Veuillez choisir une case du plateau!";
            erreur=true;        }
        if((!erreur)&&(board.isaPiece(casea,numa))&&(board.getPiece(casea,numa)->getCouleur()==couleur))
        { p=*board.getPiece(casea,numa);        }
        else{cout<<"Vous n'avez pas choisi une case contenant une pièce de votre couleur! Veuillez recommencer..."<<endl;
            erreur=true;        }
    }
    coup joue(p,vector<int>{casea,numa},vector<int>{caseb,numb},vide,Usual);
    vector<coup> coup = chessboard->liste;
    coup.push_back(joue);
    position_echec* posActuel=new position_echec(coup,1-couleur);
    return posActuel;
}


QPushButton* MainWindow::affichage_ordi(vector<int> j){
  if(j[0]==1)  {
      if(j[1]==1) {     return (ui->pushButton_A_1);      }
      else if(j[1]==2) {return (ui->pushButton_A_2);      }
      else if(j[1]==3) {return (ui->pushButton_A_3);      }
      else if(j[1]==4) {return (ui->pushButton_A_4);      }
      else if(j[1]==5) {return (ui->pushButton_A_5);      }
      else if(j[1]==6) {return (ui->pushButton_A_6);      }
      else if(j[1]==7) {return (ui->pushButton_A_7);      }
      else if(j[1]==8) {return (ui->pushButton_A_8);      }  }
  else if(j[0]==2){
      if(j[1]==1) {     return (ui->pushButton_B_1);      }
      else if(j[1]==2) {return (ui->pushButton_B_2);      }
      else if(j[1]==3) {return (ui->pushButton_B_3);      }
      else if(j[1]==4) {return (ui->pushButton_B_4);      }
      else if(j[1]==5) {return (ui->pushButton_B_5);      }
      else if(j[1]==6) {return (ui->pushButton_B_6);      }
      else if(j[1]==7) {return (ui->pushButton_B_7);      }
      else if(j[1]==8) {return (ui->pushButton_B_8);      }   }
  else if(j[0]==3){
      if(j[1]==1) {     return (ui->pushButton_C_1);      }
      else if(j[1]==2) {return (ui->pushButton_C_2);      }
      else if(j[1]==3) {return (ui->pushButton_C_3);      }
      else if(j[1]==4) {return (ui->pushButton_C_4);      }
      else if(j[1]==5) {return (ui->pushButton_C_5);      }
      else if(j[1]==6) {return (ui->pushButton_C_6);      }
      else if(j[1]==7) {return (ui->pushButton_C_7);      }
      else if(j[1]==8) {return (ui->pushButton_C_8);      }    }
  else if(j[0]==4){
      if(j[1]==1) {     return (ui->pushButton_D_1);      }
      else if(j[1]==2) {return (ui->pushButton_D_2);      }
      else if(j[1]==3) {return (ui->pushButton_D_3);      }
      else if(j[1]==4) {return (ui->pushButton_D_4);      }
      else if(j[1]==5) {return (ui->pushButton_D_5);      }
      else if(j[1]==6) {return (ui->pushButton_D_6);      }
      else if(j[1]==7) {return (ui->pushButton_D_7);      }
      else if(j[1]==8) {return (ui->pushButton_D_8);      }    }
  else if(j[0]==5){
      if(j[1]==1) {     return (ui->pushButton_E_1);      }
      else if(j[1]==2) {return (ui->pushButton_E_2);      }
      else if(j[1]==3) {return (ui->pushButton_E_3);      }
      else if(j[1]==4) {return (ui->pushButton_E_4);      }
      else if(j[1]==5) {return (ui->pushButton_E_5);      }
      else if(j[1]==6) {return (ui->pushButton_E_6);      }
      else if(j[1]==7) {return (ui->pushButton_E_7);      }
      else if(j[1]==8) {return (ui->pushButton_E_8);      }    }
  else if(j[0]==6){
      if(j[1]==1) {     return (ui->pushButton_F_1);      }
      else if(j[1]==2) {return (ui->pushButton_F_2);      }
      else if(j[1]==3) {return (ui->pushButton_F_3);      }
      else if(j[1]==4) {return (ui->pushButton_F_4);      }
      else if(j[1]==5) {return (ui->pushButton_F_5);      }
      else if(j[1]==6) {return (ui->pushButton_F_6);      }
      else if(j[1]==7) {return (ui->pushButton_F_7);      }
      else if(j[1]==8) {return (ui->pushButton_F_8);      }    }
  else if(j[0]==7){
      if(j[1]==1) {     return (ui->pushButton_G_1);      }
      else if(j[1]==2) {return (ui->pushButton_G_2);      }
      else if(j[1]==3) {return (ui->pushButton_G_3);      }
      else if(j[1]==4) {return (ui->pushButton_G_4);      }
      else if(j[1]==5) {return (ui->pushButton_G_5);      }
      else if(j[1]==6) {return (ui->pushButton_G_6);      }
      else if(j[1]==7) {return (ui->pushButton_G_7);      }
      else if(j[1]==8) {return (ui->pushButton_G_8);      }        }
  else if(j[0]==8){
      if(j[1]==1) {     return (ui->pushButton_H_1);      }
      else if(j[1]==2) {return (ui->pushButton_H_2);      }
      else if(j[1]==3) {return (ui->pushButton_H_3);      }
      else if(j[1]==4) {return (ui->pushButton_H_4);      }
      else if(j[1]==5) {return (ui->pushButton_H_5);      }
      else if(j[1]==6) {return (ui->pushButton_H_6);      }
      else if(j[1]==7) {return (ui->pushButton_H_7);      }
      else if(j[1]==8) {return (ui->pushButton_H_8);      }        }
  }




void MainWindow::on_pushButton_A_1_clicked()
{ if (clic==nullptr){ clic = ui->pushButton_A_1;
    coups.push_back({1,1} );}
  else {ui->pushButton_A_1->setText( clic->text() );
        ui->pushButton_A_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");
        coups={};}
}
void MainWindow::on_pushButton_A_2_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_A_2;
                       coups.push_back({1,2});}
  else {ui->pushButton_A_2->setText( clic->text() );
        ui->pushButton_A_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");
        coups={};}
}
void MainWindow::on_pushButton_A_3_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_A_3;
    coups.push_back({1,3} );}
  else {ui->pushButton_A_3->setText( clic->text() );
        ui->pushButton_A_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");
        coups={};}
}
void MainWindow::on_pushButton_A_4_clicked()
{ if (clic==nullptr){ clic = ui->pushButton_A_4;
                      coups.push_back({1,4} );}
  else {//on a déjà cliqué sur une case, on sélectionne la case sur laquelle on joue
        ui->pushButton_A_4->setText( clic->text() );
        ui->pushButton_A_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");
        coups={};

    }



}
void MainWindow::on_pushButton_A_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_A_5;coups.push_back({1,5} );}
  else {ui->pushButton_A_5->setText( clic->text() );
        ui->pushButton_A_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_A_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_A_6;coups.push_back({1,6} );}
  else {ui->pushButton_A_6->setText( clic->text() );
        ui->pushButton_A_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_A_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_A_7;coups.push_back({1,7} );}
  else {ui->pushButton_A_7->setText( clic->text() );
        ui->pushButton_A_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_A_8_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_A_8;coups.push_back({1,8} );}
  else {ui->pushButton_A_8->setText( clic->text() );
        ui->pushButton_A_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {1,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_B_1_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_1;coups.push_back({2,1} );}
  else {ui->pushButton_B_1->setText( clic->text() );
        ui->pushButton_B_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_2_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_2;coups.push_back({2,2} );}
  else {ui->pushButton_B_2->setText( clic->text() );
        ui->pushButton_B_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_3_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_3;coups.push_back({2,3} );}
  else {ui->pushButton_B_3->setText( clic->text() );
        ui->pushButton_B_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_4_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_4;coups.push_back({2,4} );}
  else {ui->pushButton_B_4->setText( clic->text() );
        ui->pushButton_B_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_5;coups.push_back({2,5} );}
  else {ui->pushButton_B_5->setText( clic->text() );
        ui->pushButton_B_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_6;coups.push_back({2,6} );}
  else {ui->pushButton_B_6->setText( clic->text() );
        ui->pushButton_B_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_7;
    coups.push_back({2,7} );}
  else {ui->pushButton_B_7->setText( clic->text() );
        ui->pushButton_B_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_B_8_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_B_8;
    coups.push_back({2,8} );}
  else {ui->pushButton_B_8->setText( clic->text() );
        ui->pushButton_B_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {2,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_C_1_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_1;
    coups.push_back({3,1} );}
  else {ui->pushButton_C_1->setText( clic->text() );
        ui->pushButton_C_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_2_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_2;coups.push_back({3,2} );}
  else {ui->pushButton_C_2->setText( clic->text() );
        ui->pushButton_C_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_3_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_3;
    coups.push_back({1,3} );}
  else {ui->pushButton_C_3->setText( clic->text() );
        ui->pushButton_C_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_4_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_4;
    coups.push_back({3,4} );}
  else {ui->pushButton_C_4->setText( clic->text() );
        ui->pushButton_C_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_5;
    coups.push_back({3,5} );}
  else {ui->pushButton_C_5->setText( clic->text() );
        ui->pushButton_C_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_6;
    coups.push_back({3,6} );}
  else {ui->pushButton_C_6->setText( clic->text() );
        ui->pushButton_C_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_7;
    coups.push_back({3,7} );}
  else {ui->pushButton_C_7->setText( clic->text() );
        ui->pushButton_C_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_C_8_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_C_8;
    coups.push_back({3,8} );}
  else {ui->pushButton_C_8->setText( clic->text() );
        ui->pushButton_C_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {3,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_D_1_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_1;
    coups.push_back({4,1} );}
  else {ui->pushButton_D_1->setText( clic->text() );
        ui->pushButton_D_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_2_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_2;
    coups.push_back({4,2} );}
  else {ui->pushButton_D_2->setText( clic->text() );
        ui->pushButton_D_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_3_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_3;
    coups.push_back({4,3} );}
  else {ui->pushButton_D_3->setText( clic->text() );
        ui->pushButton_D_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_4_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_4;
    coups.push_back({4,4} );}
  else {ui->pushButton_D_4->setText( clic->text() );
        ui->pushButton_D_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_5;
    coups.push_back({4,5} );}
  else {ui->pushButton_D_5->setText( clic->text() );
        ui->pushButton_D_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_6;
    coups.push_back({4,6} );}
  else {ui->pushButton_D_6->setText( clic->text() );
        ui->pushButton_D_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_D_7;
    coups.push_back({4,7} );}
  else {ui->pushButton_D_7->setText( clic->text() );
        ui->pushButton_D_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_D_8_clicked()
{coups.push_back({4,8} );
  if (clic==nullptr){ clic = ui->pushButton_D_8;}
  else {ui->pushButton_D_8->setText( clic->text() );
        ui->pushButton_D_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {4,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_E_1_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_E_1;
    coups.push_back({5,1} );}
  else {ui->pushButton_E_1->setText( clic->text() );
        ui->pushButton_E_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_2_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_E_2;
    coups.push_back({5,2} );}
  else {ui->pushButton_E_2->setText( clic->text() );
        ui->pushButton_E_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_3_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_E_3;
    coups.push_back({5,3} );}
  else {ui->pushButton_E_3->setText( clic->text() );
        ui->pushButton_E_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_4_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_E_4;
    coups.push_back({5,4} );}
  else {ui->pushButton_E_4->setText( clic->text() );
        ui->pushButton_E_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_E_5;
    coups.push_back({5,5} );}
  else {ui->pushButton_E_5->setText( clic->text() );
        ui->pushButton_E_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_E_6;
    coups.push_back({5,6} );}
  else {ui->pushButton_E_6->setText( clic->text() );
        ui->pushButton_E_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_E_7;
    coups.push_back({5,7} );}
  else {ui->pushButton_E_7->setText( clic->text() );
        ui->pushButton_E_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_E_8_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_E_8;
    coups.push_back({5,8} );}
  else {ui->pushButton_E_8->setText( clic->text() );
        ui->pushButton_E_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {5,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_F_1_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_F_1;
    coups.push_back({6,1} );}
  else {ui->pushButton_F_1->setText( clic->text() );
        ui->pushButton_F_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_2_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_F_2;
    coups.push_back({6,2} );}
  else {ui->pushButton_F_2->setText( clic->text() );
        ui->pushButton_F_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_3_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_F_3;
    coups.push_back({6,3} );}
  else {ui->pushButton_F_3->setText( clic->text() );
        ui->pushButton_F_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_4_clicked()
{ if (clic==nullptr){ clic = ui->pushButton_F_4;
    coups.push_back({6,4} );}
  else {ui->pushButton_F_4->setText( clic->text() );
        ui->pushButton_F_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_F_5;
    coups.push_back({6,5} );}
  else {ui->pushButton_F_5->setText( clic->text() );
        ui->pushButton_F_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_F_6;
    coups.push_back({6,6} );}
  else {ui->pushButton_F_6->setText( clic->text() );
        ui->pushButton_F_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_7_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_F_7;
    coups.push_back({6,7} );}
  else {ui->pushButton_F_7->setText( clic->text() );
        ui->pushButton_F_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_F_8_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_F_8;
    coups.push_back({6,8} );}
  else {ui->pushButton_F_8->setText( clic->text() );
        ui->pushButton_F_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {6,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_G_1_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_1;
    coups.push_back({7,1} );}
  else {ui->pushButton_G_1->setText( clic->text() );
        ui->pushButton_G_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_2_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_2;
    coups.push_back({7,2} );}
  else {ui->pushButton_G_2->setText( clic->text() );
        ui->pushButton_G_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_3_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_3;
    coups.push_back({7,3} );}
  else {ui->pushButton_G_3->setText( clic->text() );
        ui->pushButton_G_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_4_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_G_4;
    coups.push_back({7,4} );}
  else {ui->pushButton_G_4->setText( clic->text() );
        ui->pushButton_G_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_5_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_5;
    coups.push_back({7,5} );}
  else {ui->pushButton_G_5->setText( clic->text() );
        ui->pushButton_G_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_6_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_6;
    coups.push_back({7,6} );}
  else {ui->pushButton_G_6->setText( clic->text() );
        ui->pushButton_G_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_7;
    coups.push_back({7,7} );}
  else {ui->pushButton_G_7->setText( clic->text() );
        ui->pushButton_G_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_G_8_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_G_8;
    coups.push_back({7,8} );}
  else {ui->pushButton_G_8->setText( clic->text() );
        ui->pushButton_G_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {7,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}

void MainWindow::on_pushButton_H_1_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_H_1;
    coups.push_back({8,1} );}
  else {ui->pushButton_H_1->setText( clic->text() );
        ui->pushButton_H_1->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,1},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_2_clicked()
{ if (clic==nullptr){ clic = ui->pushButton_H_2;
    coups.push_back({8,2} );}
  else {ui->pushButton_H_2->setText( clic->text() );
        ui->pushButton_H_2->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,2},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_3_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_H_3;
    coups.push_back({8,3} );}
  else {ui->pushButton_H_3->setText( clic->text() );
        ui->pushButton_H_3->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,3},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_4_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_H_4;
    coups.push_back({8,4} );}
  else {ui->pushButton_H_4->setText( clic->text() );
        ui->pushButton_H_4->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,4},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_5_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_H_5;
    coups.push_back({8,5} );}
  else {ui->pushButton_H_5->setText( clic->text() );
        ui->pushButton_H_5->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,5},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_6_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_H_6;
    coups.push_back({8,6} );}
  else {ui->pushButton_H_6->setText( clic->text() );
        ui->pushButton_H_6->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,6},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_7_clicked()
{
  if (clic==nullptr){ clic = ui->pushButton_H_7;
    coups.push_back({8,7} );}
  else {ui->pushButton_H_7->setText( clic->text() );
        ui->pushButton_H_7->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,7},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");coups={};}
}
void MainWindow::on_pushButton_H_8_clicked()
{  if (clic==nullptr){ clic = ui->pushButton_H_8;
    coups.push_back({8,8} );}
  else {ui->pushButton_H_8->setText( clic->text() );
        ui->pushButton_H_8->setStyleSheet("color: rgb(255, 255, 255)") ;
        clic->setText(" ");
        clic = nullptr;
        //coup joueur
        echiquier board(pPosi->liste);
        piece vide;
        vector<int> coup0=coups[0];
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        coup jouer(*(board.getPiece(coup0[0],coup0[1])),coup0,vector<int> {8,8},vide,Usual);
        vector<coup> coupl=pPosi->liste;
        coupl.push_back(jouer);
        pPosi=new position_echec(coupl,1-Blanc);
        pPosi->print();
        //coups ordinateur
        pPosi=minmax(1,pPosi,Noir);
        pPosi->print();
        cout<<board.isaPiece(coup0[0],coup0[1])<<endl;
        vector<coup> listebis=pPosi->liste;
        coup current= listebis.back();
        vector<int> start=current.lastpos; //
        vector<int> goal=current.newpos;
        QPushButton* depart= affichage_ordi(start); //case de depart du coups ordinateur
        QPushButton* arrivee= affichage_ordi(goal);//case pointée correspondante
        arrivee->setText(depart->text());
        arrivee->setStyleSheet("color:rgb(0,0,0)");
        depart->setText(" ");
        coups={};}
}

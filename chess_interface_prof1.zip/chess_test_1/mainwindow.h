#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QMainWindow>
#include <QTime>
#include <QString>
#include <QTextStream>
#include "echiquier.h"
#include "position_echec.h"
#include <vector>
#include <QPushButton>
//#include "mainwindow.ui"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
  Q_OBJECT

public:
  MainWindow(QWidget *parent = nullptr);
  ~MainWindow();
  position_echec* pPosi=new position_echec({},Blanc);
  vector <vector<int>> coups;

  QPushButton* clic = nullptr;
  QPushButton* affichage_ordi(vector<int> j);

private slots:
    void on_pushButton_A_1_clicked();
  void on_pushButton_A_2_clicked();
  void on_pushButton_A_3_clicked();
  void on_pushButton_A_4_clicked();
  void on_pushButton_A_5_clicked();
  void on_pushButton_A_6_clicked();
  void on_pushButton_A_7_clicked();
  void on_pushButton_A_8_clicked();

  void on_pushButton_B_1_clicked();
  void on_pushButton_B_2_clicked();
  void on_pushButton_B_3_clicked();
  void on_pushButton_B_4_clicked();
  void on_pushButton_B_5_clicked();
  void on_pushButton_B_6_clicked();
  void on_pushButton_B_7_clicked();
  void on_pushButton_B_8_clicked();

  void on_pushButton_C_1_clicked();
  void on_pushButton_C_2_clicked();
  void on_pushButton_C_3_clicked();
  void on_pushButton_C_4_clicked();
  void on_pushButton_C_5_clicked();
  void on_pushButton_C_6_clicked();
  void on_pushButton_C_7_clicked();
  void on_pushButton_C_8_clicked();

  void on_pushButton_D_1_clicked();
  void on_pushButton_D_2_clicked();
  void on_pushButton_D_3_clicked();
  void on_pushButton_D_4_clicked();
  void on_pushButton_D_5_clicked();
  void on_pushButton_D_6_clicked();
  void on_pushButton_D_7_clicked();
  void on_pushButton_D_8_clicked();

  void on_pushButton_E_1_clicked();
  void on_pushButton_E_2_clicked();
  void on_pushButton_E_3_clicked();
  void on_pushButton_E_4_clicked();
  void on_pushButton_E_5_clicked();
  void on_pushButton_E_6_clicked();
  void on_pushButton_E_7_clicked();
  void on_pushButton_E_8_clicked();

  void on_pushButton_F_1_clicked();
  void on_pushButton_F_2_clicked();
  void on_pushButton_F_3_clicked();
  void on_pushButton_F_4_clicked();
  void on_pushButton_F_5_clicked();
  void on_pushButton_F_6_clicked();
  void on_pushButton_F_7_clicked();
  void on_pushButton_F_8_clicked();

  void on_pushButton_G_1_clicked();
  void on_pushButton_G_2_clicked();
  void on_pushButton_G_3_clicked();
  void on_pushButton_G_4_clicked();
  void on_pushButton_G_5_clicked();
  void on_pushButton_G_6_clicked();
  void on_pushButton_G_7_clicked();
  void on_pushButton_G_8_clicked();

  void on_pushButton_H_1_clicked();
  void on_pushButton_H_2_clicked();
  void on_pushButton_H_3_clicked();
  void on_pushButton_H_4_clicked();
  void on_pushButton_H_5_clicked();
  void on_pushButton_H_6_clicked();
  void on_pushButton_H_7_clicked();
  void on_pushButton_H_8_clicked();



private:
  Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H

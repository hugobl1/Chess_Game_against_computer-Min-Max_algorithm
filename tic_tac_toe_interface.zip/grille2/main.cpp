#include <iostream>
#include<cmath>
#include<stdlib.h>
#include<iostream>
#include "mainwindow.h"
#include <QDebug>
#include <QtWidgets/QApplication>




int main(int argc, char *argv[])
{ QApplication a(argc, argv);
  MainWindow w;
  w.show();
    return a.exec();
}


#include<QTextStream>
#include <QMouseEventTransition>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<iostream>
#include <QDebug>
#include<stdlib.h>
#include <QPushButton>


MainWindow::MainWindow(QWidget *parent):
  QMainWindow(parent),
  ui(new Ui::MainWindow)
{  ui->setupUi(this);
}

MainWindow::~MainWindow()
{  delete ui;}

//inline int co_to_int(int i,int j){return (i-1)*3+j-1;}


position_tictactoe :: position_tictactoe(int j1,grille g1)
{  psoeur = nullptr;
  pfille = nullptr;
        position_actuelle=g1;
  joueur=j1;}

float position_tictactoe :: valeur()
{  int val=position_actuelle.valeur();
  if(val==1) {return Q_INFINITY ;  }
  if(val==0) {return -Q_INFINITY;  }
  return 0; }


position_tictactoe* position_tictactoe::genererposition()
{  position_tictactoe* currentPos;
  int start=0;
  for(int i=1;i<4;i++)  {
    for(int j=1;j<4;j++)    {
      if(start==0)
      { grille position_fille=position_actuelle ;
        if (position_fille.jouer(i,j,1-joueur))
        { pfille = new position_tictactoe(1-joueur,position_fille);
          start+=1;
          currentPos=dynamic_cast<position_tictactoe *>(pfille); }        }
        else { grille position_fille=position_actuelle ;
        if (position_fille.jouer(i,j,1-joueur))
        {currentPos->psoeur = new position_tictactoe(1-joueur,position_fille);
         currentPos=dynamic_cast<position_tictactoe *>(currentPos->psoeur);  }
        } } }
  return dynamic_cast<position_tictactoe *>(pfille);}

bool grille::grille_pleine(){
  for(int i=0;i<9;i++){if(grille_[i]==-1){return false;}}
    return true;}

int grille::valeur()
{ //Renvoie 0 si c'est l'humain qui gagne
  //Renvoie 1 si c'est la machine qui gagne
  //Renvoie 2 en cas de match nul
  int matche_nul = 2 ;
  //on teste les lignes
  for (int joueur=0;joueur<2;joueur++){
    for(int i=1;i<4;i++)
    {if ((grille_[(i-1)*3]==joueur) && (grille_[(i-1)*3+1]==joueur) && (grille_[(i-1)*3+2]==joueur)){return joueur;}    }
    //on teste les colonnes
    for(int j=0;j<3;j++)    {
      if ((grille_[j]==joueur) && (grille_[3+j]==joueur) && (grille_[6+j]==joueur)){return joueur;}    }
    //on teste les diagonales
    if ((grille_[0]==joueur) && (grille_[4]==joueur) && (joueur==grille_[8])){return joueur;}
    if ((grille_[2]==joueur) && (grille_[4]==joueur) && (grille_[6]==joueur)){return joueur;}
  }
  return matche_nul ;
}

bool grille::jouer(int i,int j,int joueur){
    if(this->valeur()==1 || this->valeur()==0){return false;}
    if (grille_[co_to_int(i,j)]==-1 && i<4 && j<4){grille_[co_to_int(i,j)]=joueur;return true;}
    else
      return false;}


void grille::afficher_case(int i,int j)
{  if(grille_[co_to_int(i,j)]==0)
  {
     std :: cout  << " O ";
  }
  if(grille_[co_to_int(i,j)]==1)
  {
     std :: cout  << " X ";
  }
  if(grille_[co_to_int(i,j)]==-1)
  {
     std :: cout  << "   ";
  }
  if(j==3)
  {
    std::cout << "]" << std :: endl ;
  }
}

void grille :: afficher_grille()
{
  for(int i=1;i<4;i++)
  {
    std :: cout << "[" ;
    for(int j=1;j<4;j++)
    {
      afficher_case(i,j);
    }
  }
}

//mod

//met à jour l'affichage
void MainWindow::update( grille g ) {
    if(g.grille_[co_to_int(1,1)]==0) {ui->pushButton_1_1->setText("O");}
    if(g.grille_[co_to_int(1,1)]==1) {ui->pushButton_1_1->setText("X");}
    if(g.grille_[co_to_int(1,1)]==-1){ui->pushButton_1_1->setText(" ");}
    if(g.grille_[co_to_int(1,2)]==0) {ui->pushButton_1_2->setText("O");}
    if(g.grille_[co_to_int(1,2)]==1) {ui->pushButton_1_2->setText("X");}
    if(g.grille_[co_to_int(1,2)]==-1){ui->pushButton_1_2->setText(" ");}
    if(g.grille_[co_to_int(1,3)]==0) {ui->pushButton_1_3->setText("O");}
    if(g.grille_[co_to_int(1,3)]==1) {ui->pushButton_1_3->setText("X");}
    if(g.grille_[co_to_int(1,3)]==-1){ui->pushButton_1_3->setText(" ");}

    if(g.grille_[co_to_int(2,1)]==0) {ui->pushButton_2_1->setText("O");}
    if(g.grille_[co_to_int(2,1)]==1) {ui->pushButton_2_1->setText("X");}
    if(g.grille_[co_to_int(2,1)]==-1){ui->pushButton_2_1->setText(" ");}
    if(g.grille_[co_to_int(2,2)]==0) {ui->pushButton_2_2->setText("O");}
    if(g.grille_[co_to_int(2,2)]==1) {ui->pushButton_2_2->setText("X");}
    if(g.grille_[co_to_int(2,2)]==-1){ui->pushButton_2_2->setText(" ");}
    if(g.grille_[co_to_int(2,3)]==0) {ui->pushButton_2_3->setText("O");}
    if(g.grille_[co_to_int(2,3)]==1) {ui->pushButton_2_3->setText("X");}
    if(g.grille_[co_to_int(2,3)]==-1){ui->pushButton_2_3->setText(" ");}

    if(g.grille_[co_to_int(3,1)]==0) {ui->pushButton_3_1->setText("O");}
    if(g.grille_[co_to_int(3,1)]==1) {ui->pushButton_3_1->setText("X");}
    if(g.grille_[co_to_int(3,1)]==-1){ui->pushButton_3_1->setText(" ");}
    if(g.grille_[co_to_int(3,2)]==0) {ui->pushButton_3_2->setText("O");}
    if(g.grille_[co_to_int(3,2)]==1) {ui->pushButton_3_2->setText("X");}
    if(g.grille_[co_to_int(3,2)]==-1){ui->pushButton_3_2->setText(" ");}
    if(g.grille_[co_to_int(3,3)]==0) {ui->pushButton_3_3->setText("O");}
    if(g.grille_[co_to_int(3,3)]==1) {ui->pushButton_3_3->setText("X");}
    if(g.grille_[co_to_int(3,3)]==-1){ui->pushButton_3_3->setText(" ");}

  }

void MainWindow::coup_ordinateur(){
  jeu=*dynamic_cast<position_tictactoe *>(minmax(9,&jeu));

  jeu.position_actuelle.afficher_grille();
  update(jeu.position_actuelle);
  jeu.joueur=1-jeu.joueur;
}



//met à joueur les cases jouées
void MainWindow::on_pushButton_1_1_clicked(){jeu.position_actuelle.jouer(1,1,0);coup_ordinateur();}
void MainWindow::on_pushButton_1_2_clicked(){jeu.position_actuelle.jouer(1,2,0);coup_ordinateur();}
void MainWindow::on_pushButton_1_3_clicked(){jeu.position_actuelle.jouer(1,3,0);coup_ordinateur();}
void MainWindow::on_pushButton_2_1_clicked(){jeu.position_actuelle.jouer(2,1,0);coup_ordinateur();}
void MainWindow::on_pushButton_2_2_clicked(){jeu.position_actuelle.jouer(2,2,0);coup_ordinateur();}
void MainWindow::on_pushButton_2_3_clicked(){jeu.position_actuelle.jouer(2,3,0);coup_ordinateur();}
void MainWindow::on_pushButton_3_1_clicked(){jeu.position_actuelle.jouer(3,1,0);coup_ordinateur();}
void MainWindow::on_pushButton_3_2_clicked(){jeu.position_actuelle.jouer(3,2,0);coup_ordinateur();}
void MainWindow::on_pushButton_3_3_clicked(){jeu.position_actuelle.jouer(3,3,0);coup_ordinateur();}

//int co_to_int(int i,int j){return (i-1)*3+j-1;}

/*
//met à joueur les cases jouées
void MainWindow::on_pushButton_1_1_clicked(){jeu->position_actuelle.jouer(1,1,0);coup_ordinateur();}
void MainWindow::on_pushButton_1_2_clicked(){jeu->position_actuelle.jouer(1,2,0);coup_ordinateur();}
void MainWindow::on_pushButton_1_3_clicked(){jeu->position_actuelle.jouer(1,3,0);coup_ordinateur();}
void MainWindow::on_pushButton_2_1_clicked(){jeu->position_actuelle.jouer(2,1,0);coup_ordinateur();}
void MainWindow::on_pushButton_2_2_clicked(){jeu->position_actuelle.jouer(2,2,0);coup_ordinateur();}
void MainWindow::on_pushButton_2_3_clicked(){jeu->position_actuelle.jouer(2,3,0);coup_ordinateur();}
void MainWindow::on_pushButton_3_1_clicked(){jeu->position_actuelle.jouer(3,1,0);coup_ordinateur();}
void MainWindow::on_pushButton_3_2_clicked(){jeu->position_actuelle.jouer(3,2,0);coup_ordinateur();}
void MainWindow::on_pushButton_3_3_clicked(){jeu->position_actuelle.jouer(3,3,0);coup_ordinateur();}
*/




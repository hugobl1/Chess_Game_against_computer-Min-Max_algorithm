#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QMainWindow>
//#include <QVector>
//#include <QPushButton>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

inline int co_to_int(int i,int j){return (i-1)*3+j-1;}

class grille
{ public :
  int grille_[9]={-1,-1,-1,-1,-1,-1,-1,-1,-1};
  //A faire un constructeur par copie
  int & operator()(int i,int j){return grille_[co_to_int(i,j)];}
  bool jouer(int i,int j,int joueur);
  int valeur();
  ~grille(){}
  void afficher_case(int,int);
  void afficher_grille();
  bool grille_pleine();

};

class position
{public:
	position* psoeur;
	position* pfille;
	int joueur;
	//les fonctions
	virtual float valeur()=0;
	virtual position* genererposition()=0;
	//virtual ~position();
};



class position_tictactoe : public position
{ public:
  grille position_actuelle ;
  virtual float valeur();
  position_tictactoe(int ,grille);
        virtual position_tictactoe* genererposition();
        ~position_tictactoe(){};
  virtual void affiche(){position_actuelle.afficher_grille();}

};

inline double minmax_val(int deep,position* P){
	if (deep==0){return P->valeur();}
	P->genererposition();
	if (P->pfille ==0){return P->valeur();}
	double extremum=minmax_val(deep-1,P->pfille);
	position* courant=(P->pfille)->psoeur;

	if (courant==0){return extremum;}
	if (courant->joueur==1){
		//max
		while(courant!=0){
			double temp=minmax_val(deep-1,courant);
			if(temp >= extremum){extremum=temp;}
				courant=courant->psoeur;
			}
		}

	if (courant==0){return extremum;}
	if (courant->joueur==0){
	//min
		while(courant!=0){
			double temp =minmax_val(deep-1,courant);
			if(temp <= extremum){extremum=temp;}
				courant=courant->psoeur;
			}
	}
	return extremum;
}

inline position* minmax(int deep,position* P){
	P->genererposition();
	position* extremum=P->pfille;
	if(extremum==0){return P;}
	position* courant=(P->pfille)->psoeur;
	while(courant!=0){
		//max
		if(minmax_val(deep-1,extremum)<=minmax_val(deep-1,courant)){extremum=courant;}
		courant=courant->psoeur;
	}
	return extremum;
}


class MainWindow : public QMainWindow
{  Q_OBJECT

public:
  MainWindow(QWidget *parent = nullptr);
  ~MainWindow();
   grille g;
   position_tictactoe jeu=*(new position_tictactoe(0,g));
   void update(grille g);
   void coup_ordinateur(); //mod

private slots:
  void on_pushButton_1_1_clicked();
  void on_pushButton_1_2_clicked();
  void on_pushButton_1_3_clicked();
  void on_pushButton_2_1_clicked();
  void on_pushButton_2_2_clicked();
  void on_pushButton_2_3_clicked();
  void on_pushButton_3_1_clicked();
  void on_pushButton_3_2_clicked();
  void on_pushButton_3_3_clicked();


 private:
  Ui::MainWindow *ui;
   //grille g; //mod
   //position_tictactoe jeu; //mod
};


#endif // MAINWINDOW_H

#ifndef POSITION_H
#define POSITION_H


#include <QtWidgets/QMainWindow>
#include <QVector>
#include <QPushButton>
#include<iostream>
#include<mainwindow.h>
//#include<stdlib.h>

/////On a joueur machine=1 et joueur humain=0
class position
{public:
	position* psoeur;
	position* pfille;
	int joueur;
	//les fonctions
	virtual float valeur()=0;
	virtual position* genererposition()=0;
	//virtual ~position();
};


double minmax_val(int deep,position* P){
	if (deep==0){return P->valeur();}
	P->genererposition();
	if (P->pfille ==0){return P->valeur();}
	double extremum=minmax_val(deep-1,P->pfille);
	position* courant=(P->pfille)->psoeur;

	if (courant==0){return extremum;}
	if (courant->joueur==1){
		//max
		while(courant!=0){
			double temp=minmax_val(deep-1,courant);
			if(temp >= extremum){extremum=temp;}
				courant=courant->psoeur;
			}
		}

	if (courant==0){return extremum;}
	if (courant->joueur==0){
	//min
		while(courant!=0){
			double temp =minmax_val(deep-1,courant);
			if(temp <= extremum){extremum=temp;}
				courant=courant->psoeur;
			}
	}
	return extremum;
}

position* minmax(int deep,position* P){
	P->genererposition();
	position* extremum=P->pfille;
	if(extremum==0){return P;}
	position* courant=(P->pfille)->psoeur;
	while(courant!=0){
		//max
		if(minmax_val(deep-1,extremum)<=minmax_val(deep-1,courant)){extremum=courant;}
		courant=courant->psoeur;
	}
	return extremum;
}


class position_tictactoe : public position
{ public:
  grille position_actuelle ;
  virtual float valeur();
  position_tictactoe(int ,grille);
        virtual position_tictactoe* genererposition();
        ~position_tictactoe(){};
  virtual void affiche(){position_actuelle.afficher_grille();}

};

position_tictactoe :: position_tictactoe(int j1,grille g1)
{  psoeur = nullptr;
  pfille = nullptr;
        position_actuelle=g1;
  joueur=j1;}

float position_tictactoe :: valeur()
{  int val=position_actuelle.valeur();
  if(val==1) {return Q_INFINITY ;  }
  if(val==0) {return -Q_INFINITY;  }
  return 0; }


position_tictactoe* position_tictactoe::genererposition()
{  position_tictactoe* currentPos;
  int start=0;
  for(int i=1;i<4;i++)  {
    for(int j=1;j<4;j++)    {
      if(start==0)
      { grille position_fille=position_actuelle ;
        if (position_fille.jouer(i,j,1-joueur))
        { pfille = new position_tictactoe(1-joueur,position_fille);
          start+=1;
          currentPos=dynamic_cast<position_tictactoe *>(pfille); }        }
        else { grille position_fille=position_actuelle ;
        if (position_fille.jouer(i,j,1-joueur))
        {currentPos->psoeur = new position_tictactoe(1-joueur,position_fille);
         currentPos=dynamic_cast<position_tictactoe *>(currentPos->psoeur);  }
        } } }
  return dynamic_cast<position_tictactoe *>(pfille);}

#endif // POSITION_H
